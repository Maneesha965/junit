package com.infosys.dao;

import java.util.List;

import com.infosys.entity.Gadget;

public interface InfyKartDAO {

	boolean addGadget(Gadget gadget);

	Gadget getGadget(int gadgetId);

	float updateGadgetPrice(int gadgetId, float newPrice);

	int updateGadgetQuantity(int gadgetId, int newQuantity);

	boolean removeGadget(int gadgetId);

	List<Gadget> viewAllGadgets();

}