package com.infosys.client;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.infosys.entity.Gadget;
import com.infosys.service.InfyKartService;
import com.infosys.service.InfyKartServiceImpl;

public class InfyKart {
	private static final Logger logger = Logger.getLogger(InfyKart.class.toString());

	public static void main(String[] args) {
		InfyKartService infyKartService = new InfyKartServiceImpl();
		try {
			Gadget g = new Gadget(104, "Desktop", "HP", 20000, 2);
			String result = infyKartService.addGadget(g);
			logger.info(result);
			g = infyKartService.getGadget(105);
			logger.info("" + g);
			float newPrice = infyKartService.updateGadgetPrice(101, -92000);
			logger.info("New price is " + newPrice);
			int newQuantity = infyKartService.updateGadgetQuantity(103, 4);
			logger.info("New quantity is " + newQuantity);
			boolean flag = infyKartService.removeGadget(102);
			logger.info("Deletion status  : "+flag);
			List<Gadget> gadgetList = infyKartService.viewAllGadgets();
			for (Gadget gadget : gadgetList) {
				logger.info("" + gadget);
			}
		} catch (Exception e) {
			logger.log(Level.WARNING, e.getMessage());
		}

	}

}
