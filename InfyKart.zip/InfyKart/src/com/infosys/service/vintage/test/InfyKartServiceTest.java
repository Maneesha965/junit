package com.infosys.service.vintage.test;

import static org.junit.Assert.assertEquals;

import java.util.logging.Logger;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.infosys.entity.Gadget;
import com.infosys.exception.InfyKartException;
import com.infosys.service.InfyKartService;
import com.infosys.service.InfyKartServiceImpl;

public class InfyKartServiceTest {
	private final Logger logger = Logger.getLogger(InfyKartServiceTest.class.toString());

	private InfyKartService infyKartService;

	@Rule
	public ExpectedException ee = ExpectedException.none();

	@Before
	public void setUp() {
		logger.info("Inside Before in method: ");
		infyKartService = new InfyKartServiceImpl();
	}

	@Test
	public void addGadgetValidTest() throws InfyKartException {
		Gadget gadget = new Gadget(201, "Laptop", "Apple", 99000, 10);
		assertEquals("New Gadget added successfully.", infyKartService.addGadget(gadget));
	}

	@Test
	public void addGadgetInValidTest() throws InfyKartException {
		Gadget gadget = new Gadget(101, "Laptop", "HP", 90000, 50);
		ee.expect(InfyKartException.class);
		ee.expectMessage("Gadget already available.");
		infyKartService.addGadget(gadget);
	}

	@After
	public void destroy() {
		logger.info("Inside After in method: ");
		infyKartService = null;
	}

}
