package com.infosys.service;

import java.util.List;

import com.infosys.entity.Gadget;
import com.infosys.exception.InfyKartException;

public interface InfyKartService {

	String addGadget(Gadget gadget) throws InfyKartException;

	Gadget getGadget(int gadgetId);

	float updateGadgetPrice(int gadgetId, float newPrice) throws InfyKartException;

	int updateGadgetQuantity(int gadgetId, int newQuantity);

	boolean removeGadget(int gadgetId);

	List<Gadget> viewAllGadgets();

}